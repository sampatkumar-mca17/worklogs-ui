import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {ViewAllComponent} from './view-all/view-all.component'

const routes: Routes = [
    { path: 'view-all', component: ViewAllComponent },
    { path: '',   redirectTo: '/view-all', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class WorklogsRoutingModule { }