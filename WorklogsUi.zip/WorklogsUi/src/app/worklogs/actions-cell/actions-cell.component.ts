import { Component, OnInit } from '@angular/core';
import { faEdit, faTrashAlt, faCloudDownloadAlt } from '@fortawesome/free-solid-svg-icons';
import { ICellRendererAngularComp } from 'ag-grid-angular'
@Component({
  selector: 'app-actions-cell',
  templateUrl: './actions-cell.component.html',
  styleUrls: ['./actions-cell.component.scss']
})
export class ActionsCellComponent implements OnInit, ICellRendererAngularComp{

  faCloudDownload = faCloudDownloadAlt
  faTrashAlt = faTrashAlt
  faEdit = faEdit
  public params
  
  constructor() { }

  ngOnInit(): void {
  }

  agInit(params: any): void {
    this.params = params
  }

  invokeEdit(){
    this.params.context.componentParent.openEditDialog(this.params.value)
  }

  invokeDelete(){
    this.params.context.componentParent.openDeleteDialog(this.params.value)
  }
  refresh(): boolean {
    return false
  }

}
