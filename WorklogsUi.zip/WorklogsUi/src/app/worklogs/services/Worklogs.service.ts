import { Injectable } from '@angular/core'
import { HttpClient } from '@angular/common/http'


@Injectable()
export class WorklogsService {

  constructor(private readonly _httpClient: HttpClient) {}

  fetchWorklogs() {
    return this._httpClient
      .get(`http://0.0.0.0:8000/rest/v1/user/u1/worklogs`)
  }

  uploadWorklogs(data){
      return this._httpClient
      .post(`http://0.0.0.0:8000/rest/v1/user/u1/worklogs`,data)
  }
  
  updateWorklogs(data, project_id){
    return this._httpClient
    .put(`http://0.0.0.0:8000/rest/v1/user/u1/worklogs/${project_id}`,data)
  }
  deleteWorklogs(project_id){
    return this._httpClient
    .delete(`http://0.0.0.0:8000/rest/v1/user/u1/worklogs/${project_id}`)
  }

  send_mail(data){
    return this._httpClient
    .post(`http://0.0.0.0:8000/send_mail`,data)
  } 
}