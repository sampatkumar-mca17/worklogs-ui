import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ViewAllComponent } from './view-all/view-all.component';
import { WorklogsRoutingModule } from './worklogs-routing.module'
import { MatToolbarModule } from '@angular/material/toolbar'
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome'
import { AgGridModule } from 'ag-grid-angular'
import { PComponentsModule } from '../p-components/p-components.module'
import { MatButtonModule } from '@angular/material/button';
import { ActionsCellComponent } from './actions-cell/actions-cell.component'
import { WorklogsService } from './services/Worklogs.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [ViewAllComponent, ActionsCellComponent],
  imports: [
    CommonModule,
    WorklogsRoutingModule,
    MatToolbarModule,
    FontAwesomeModule,
    AgGridModule.withComponents([]),
    PComponentsModule,
    MatButtonModule,
    FormsModule,
    ReactiveFormsModule

  ],
  exports: [ViewAllComponent],
  providers: [WorklogsService],
})
export class WorklogsModule { }
