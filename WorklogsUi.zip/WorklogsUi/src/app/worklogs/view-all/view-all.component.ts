import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { faUser, faUndo } from '@fortawesome/free-solid-svg-icons';
import { GridApi } from 'ag-grid-community';
import { ActionsCellComponent } from '../actions-cell/actions-cell.component'
import {WorklogsService} from '../services/Worklogs.service'

@Component({
  selector: 'view-all',
  templateUrl: './view-all.component.html',
  styleUrls: ['./view-all.component.scss', '../styles.scss']
})
export class ViewAllComponent implements OnInit {
  faUser = faUser
  faUndo = faUndo
  private gridApi: GridApi;
  public context = { componentParent: this }
  defaultColDef: { resizable: boolean; sortable: boolean; };
  loadingOverlayComponent: string;
  paginationPageSize = 10
  openPopup: boolean = true
  @ViewChild('dialog', { static: true }) dialog;
  columnDefs = [
    { headerName: 'Project', field: "project_name", sortable: true, filter: true },
    { headerName: 'Time Logged', field: "log_hours", sortable: true, filter: true },
    { headerName: 'Created On', field: "created_on", sortable: true, filter: true },
    { headerName: 'Description', field: "project_description", sortable: true, filter: true },

    {
      headerName: 'Actions',
      sortable: true,
      field: 'project_id',
      cellRenderer: 'actionCellRenderer',
      cellClass: 'alignCenter',
      width: 250,
      pinned: 'right',
    },
  ];

  rowData = []

  public frameworkComponents = {
    actionCellRenderer: ActionsCellComponent
  }

  constructor(private elem: ElementRef, private _service:WorklogsService) {
    this.defaultColDef = {
      resizable: true,
      sortable: true,
    }
    this.loadingOverlayComponent = 'customLoadingOverlay'
  }

  ngOnInit(): void {
   this._service.fetchWorklogs().subscribe(
     (data:any) => {
       this.rowData = data
     }
   )
  }

  onGridReady(params) {
    this.gridApi = params.api;
    const sortModel = [
      {colId: 'id', sort: 'asc'}
    ];
    this.gridApi.setSortModel(sortModel);
    params.api.sizeColumnsToFit();
  }
  openEditDialog(id) {
    let editFields = this.rowData.filter(function (field) {
      return field.project_id == id
    })
    let edit_data = {
      "project": editFields[0]['project_name'],
      "date": editFields[0]['created_on'],
      "timelogged": editFields[0]['log_hours'],
      "project_id": editFields[0]['project_id'],
      "description": editFields[0]['project_description']
    }
    this.dialog.openDialog({content:edit_data, title:"Edit Workflow", disabledFields:["project","date","description"], hideFields:["project_id"], optionalReturnVals:{type:"update"}, btnTitle:"Update Workflow", contentType:"dynamic"})
  }

  openInsertDialog(){
    let insertObj = {project:'',timelogged:'', description:''}
    this.dialog.openDialog({content:insertObj,title:"Upload Workflow", optionalReturnVals:{type:"insert"}, btnTitle:"Upload Workflow", contentType:"dynamic"})
  }

  openDeleteDialog(id){
    let delete_data = this.rowData.filter(function (field) {
      return field.project_id == id
    })
    let message="Are you sure you want to delete worklog for project: "+delete_data[0]['project_name']
    this.dialog.openDialog({content:message, title:"Delete Workflow" , optionalReturnVals:{type:"delete",id:id}, btnTitle:"Delete Workflow", contentType:"static"})
  }

  dialogResultEvent(event){
    if(event.optionalReturnVals.type == "update"){
      this.update(event.result)
    }
    else if(event.optionalReturnVals.type == "insert"){
      this.insert(event.result)
    }
    else if(event.optionalReturnVals.type == "delete"){
      this.delete(event.optionalReturnVals.id)
    }
  }

  update(row) {
    
    if (row) {
      
      let updatable_data = {
        "project_name":row.project,
        "log_hours": row.timelogged,
      }
      console.log(updatable_data)
      this._service.updateWorklogs(updatable_data, row.project_id).subscribe((data:any)=>{
        console.log(data)
        this._service.fetchWorklogs().subscribe((data:any)=>{
          this.rowData = data
          this.gridApi.setRowData(this.rowData) 
        })
      })
    }
    

  }

  insert(row){
    let data = {
      project_name: row["project"],
      log_hours: row["timelogged"],
      project_description: row['description']
    }
    this._service.uploadWorklogs(data).subscribe((data:any) => {
      this._service.fetchWorklogs().subscribe((data:any) => {
        this.rowData = data
        this.gridApi.setRowData(this.rowData)
      })
    })
  }

  delete(id){
    this._service.deleteWorklogs(id).subscribe((data:any)=>{
      this._service.fetchWorklogs().subscribe((data:any) => {
        this.rowData = data
        this.gridApi.setRowData(this.rowData)
      })
    })
    
  }
  
  refresh(){
    this._service.fetchWorklogs().subscribe((data:any) => {
      this.rowData = data
      this.gridApi.setRowData(this.rowData)
    })
  }

  send_mail(){
    let data = {
      body:this.rowData
    }
    this._service.send_mail(data).subscribe((data:any)=>{
      alert("Mail sent")
    })
  }
}
