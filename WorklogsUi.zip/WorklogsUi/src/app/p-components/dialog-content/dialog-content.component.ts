import { Component, ComponentRef, Inject, OnInit, SimpleChanges, ViewChild, OnChanges } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { NgForm } from '@angular/forms';
@Component({
  selector: 'dialog-content',
  templateUrl: './dialog-content.component.html',
  styleUrls: ['./dialog-content.component.scss']
})
export class DialogContentComponent implements OnInit {

  content:any
  title:string
  width:any
  changedContent:any
  disabledFields:Object
  hideFields:Object
  btnTitle: string
  contentType: string
  returnVals:Object
  @ViewChild(DialogContentComponent) dialogContent: ComponentRef<DialogContentComponent> 
  errors: any;
  constructor(public dialogRef: MatDialogRef<DialogContentComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
      this.content = data.content
      this.changedContent = JSON.parse(JSON.stringify(data.content))
      this.title = data.title
      this.disabledFields = data.disabledFields
      this.hideFields = data.hideFields
      this.btnTitle = data.btnTitle
      this.contentType = data.contentType
      this.returnVals = data.returnVals
     }

     onChanges(key,value){
       this.changedContent[key]=value
     }

     closeDialog(button:string){
        if (button == "primaryDynamicButton"){
          Object.keys(this.changedContent).forEach((key)=>{ 
              if(!this.changedContent[key]){
              this.errors = true
            } 
            else{
              this.errors = false
            }
          })
          if(!this.errors){
            this.dialogRef.close({result:this.changedContent,optionalReturnVals:this.returnVals});
          }
          else 
            alert("Error in form please check!")
        }
        else if(button == "primaryStaticButton"){
            this.dialogRef.close({optionalReturnVals:this.returnVals});
        }
        else
          this.dialogRef.close()
     }

  ngOnInit(): void {
  }

}
