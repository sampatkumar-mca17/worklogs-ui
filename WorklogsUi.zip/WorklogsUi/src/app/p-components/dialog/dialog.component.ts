import { Component, ComponentRef, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DialogContentComponent } from '../dialog-content/dialog-content.component'

@Component({
  selector: 'app-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.scss']
})
export class DialogComponent implements OnInit {
  @Input() fields: Object
  @Output() result = new EventEmitter<Object>();

  constructor(public dialog: MatDialog) {
  }

  ngOnInit(): void {
  }

  openDialog({ content="No Content", title="No Title", btnTitle="Button", contentType="static", hideFields = [], disabledFields =[], optionalReturnVals = "" }: dialogParams) {
    let dialogRef = this.dialog.open(DialogContentComponent, {
      width: '40vw',
      data: {
        content: content,
        title: title,
        disabledFields: disabledFields,
        hideFields: hideFields,
        btnTitle: btnTitle,
        contentType: contentType,
        returnVals: optionalReturnVals
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log(result)
      if (result)
        this.result.emit(result)
    });
  }

}

interface dialogParams {
  content: any,
  title: string,
  contentType: string,
  btnTitle: string,
  hideFields: Object,
  optionalReturnVals: string,
  disabledFields: Object
}

