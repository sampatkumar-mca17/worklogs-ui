import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'btn-var',
  templateUrl: './btn-var.component.html',
  styleUrls: ['./btn-var.component.scss']
})
export class BtnVarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  @Input() btnTitle = ''
  @Input() additionalClasses = ''
  @Input() ngClass: any = {}
  @Input() btnDisabled = false

  @Output() onclick = new EventEmitter<any>()
}
