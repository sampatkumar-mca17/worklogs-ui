import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BtnVarComponent } from './btn-var.component';

describe('BtnVarComponent', () => {
  let component: BtnVarComponent;
  let fixture: ComponentFixture<BtnVarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BtnVarComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BtnVarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
