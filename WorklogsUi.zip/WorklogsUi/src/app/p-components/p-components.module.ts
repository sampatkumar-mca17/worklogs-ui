import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './header/header.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome'
import { MatToolbarModule } from '@angular/material/toolbar';
import { ScrBrdCrumbComponent } from './scr-brd-crumb/scr-brd-crumb.component';
import { MatButtonModule } from '@angular/material/button'
import { BtnVarComponent } from './btn-var/btn-var.component';
import { DialogComponent } from './dialog/dialog.component'
import { MatDialogModule } from '@angular/material/dialog';
import { DialogContentComponent } from './dialog-content/dialog-content.component';
import { FooterComponent } from './footer/footer.component'
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [HeaderComponent, ScrBrdCrumbComponent, BtnVarComponent, DialogComponent, DialogContentComponent, FooterComponent],
  imports: [
    CommonModule,
    FontAwesomeModule,
    MatToolbarModule,
    MatButtonModule,
    MatDialogModule,
    FormsModule,
    ReactiveFormsModule
  ],
  entryComponents:[MatDialogModule,DialogContentComponent],
  exports: [HeaderComponent, BtnVarComponent, ScrBrdCrumbComponent, DialogComponent, FooterComponent],
})
export class PComponentsModule { }
