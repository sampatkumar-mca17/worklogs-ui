import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ScrBrdCrumbComponent } from './scr-brd-crumb.component';

describe('ScrBrdCrumbComponent', () => {
  let component: ScrBrdCrumbComponent;
  let fixture: ComponentFixture<ScrBrdCrumbComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ScrBrdCrumbComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ScrBrdCrumbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
