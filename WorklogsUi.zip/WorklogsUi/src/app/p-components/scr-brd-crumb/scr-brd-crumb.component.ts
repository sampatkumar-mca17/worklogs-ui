import { Component, Input, OnInit } from '@angular/core';
import { faAngleDoubleRight, faChevronRight, faRulerHorizontal } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'scr-brd-crumb',
  templateUrl: './scr-brd-crumb.component.html',
  styleUrls: ['./scr-brd-crumb.component.scss']
})
export class ScrBrdCrumbComponent implements OnInit {
  faChevronRight = faChevronRight
  faAngleDoubleRight = faAngleDoubleRight
  faHorizontalRule = faRulerHorizontal

  @Input() parent = ''
  @Input() child = ''
  @Input() size = ''
  constructor() { }

  ngOnInit(): void {
  }

}
