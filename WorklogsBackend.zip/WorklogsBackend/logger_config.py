import logging
import uuid

from flask import g


class LoggerConfig(object):
    """
    Logger config class.
    """

    @staticmethod
    def create_logger(log_level):
        """
        Creates stream handler and attaches to the python root logger.

        :param log_level: log level
        """

        custom_logger = logging.getLogger()
        # Removing existing handler
        if custom_logger.hasHandlers():
            custom_logger.handlers.pop()
        custom_logger.propagate = False
        custom_logger.setLevel(log_level)

        handler = logging.StreamHandler()
        handler.setLevel(log_level)
        handler.setFormatter(
            logging.Formatter(
                "[%(asctime)s] [%(levelname)s] [%(correlation_id)s] [%(thread)d] [%(filename)s:%(lineno)d] "
                "---- %(message)s")
        )
        custom_logger.addHandler(handler)

        # Adding custom handler to internal Flask logger to have consistent logging
        werkzeug_logger = logging.getLogger('werkzeug')
        werkzeug_logger.propagate = False
        werkzeug_logger.addHandler(handler)

