from setuptools import setup, find_packages

setup(
    name='Uptime Analytics Automations',
    version='20.3',
    description='Uptime Analytics Automations',
    author='Akshay Tigga',
    author_email='akshay.tigga@syncron.com',
    packages=find_packages(),
    install_requires=['pytest','mock','requests','moto','aws_lambda_context','flask','flask_cors','pytest-cov'],
)