
from flask import Flask, Blueprint, request, jsonify
import json
from flask_cors import CORS
from utils.db_query_event_handler import DatabaseEventHandler
from controller.worklogs_controller import worklogs
from service import send_mail_service
from Config.request_interceptor import request_interceptor
from model import db
from model import marshmallow,  migrate
from model.database_service import DatabaseManagementService
from utils import config
from config import Config


app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = Config().SQLALCHEMY_DATABASE_URI
with app.app_context():
        db.init_app(app)
        marshmallow.init_app(app)
        migrate.init_app(app, db)
        DatabaseManagementService.manage_db()
        DatabaseEventHandler()

app.config['MAIL_SERVER']='smtp.gmail.com'
app.config['MAIL_PORT'] = 465
app.config['MAIL_USERNAME'] = config.MAIL_USERNAME
app.config['MAIL_PASSWORD'] = config.MAIL_PASSWORD
app.config['MAIL_USE_TLS'] = False
app.config['MAIL_USE_SSL'] = True
app.register_blueprint(request_interceptor)
app.register_blueprint(worklogs)
send_mail_api = Blueprint('send_mail_api', __name__, url_prefix='/send_mail')
app.register_blueprint(send_mail_api)
CORS(app)

@app.route('/send_mail', methods=['POST'])
def send_mail():
        response = send_mail_service.send_mail(app, request.json)
        return jsonify(response)

if __name__ == "__main__":
        app.run(host='0.0.0.0', port=8000, debug=False, threaded=True)