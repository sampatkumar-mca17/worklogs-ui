import logging

# from app.analytics.utils.aws_services_config import get_rds_host_name
from logger_config import LoggerConfig


class Config(object):
    # SQLALCHEMY_DATABASE_URI = get_rds_host_name()
    SQLALCHEMY_DATABASE_URI = 'postgresql://postgres:root@127.0.0.1:5432/sam3'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    MAX_CONTENT_LENGTH = 100 * 1024 * 1024

    @classmethod
    def init_app(cls):
        LoggerConfig.create_logger(cls.get_log_level())

    @classmethod
    def get_log_level(cls):
        return logging.INFO


class DevelopmentConfig(Config):
    # Dev environment specific config goes here
    pass


class QAConfig(Config):
    # QA environment specific config goes here
    pass


class StagingConfig(Config):
    # Staging environment specific config goes here
    pass


class ProductionConfig(Config):
    # Prod environment specific config goes here
    pass


config = {
    'devdemo': DevelopmentConfig,
    'qa': QAConfig,
    'prod': ProductionConfig,
    'staging': StagingConfig
}
