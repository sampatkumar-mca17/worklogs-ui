# Uptime Analytics

Uptime analytics is the product web portal that facilitates uptime analytics data science users can upload their machine learning models for real-time predictions. Uptime analytics contains UI screens for the following things,
 
1. Upload screen is to Upload new model
2. Deploy screen is to Deploy the saved the model
3. Home screen is used to view the existing model and deployment details 


Uptime analytics contains the following layers. commons, datahub integration, prediction layer, serving layer, serving layer handler, workbench.


## Components

| Name          | Description   |Libraries |  
| ------------- | ------------- |---------------|               
|Workbench  | This layer contains the set of flask API endpoints which will provide the backend implementation for to upload new model, view the existing saved model, view the deployment details,product applicability, etc..| Sqlalchemy, Flask            | 
|Serving Layer|This layer contains the set of flask API endpoints which will provide the backend implementation for the support  of  data processing and convertion of data according to the ML model metadata and handling the prediction services| Flask|
|Prediction Layer|This layer contains the set of flask API endpoints which will provide the backend implementation for the support of prediction and the generation of the prediction events |Sagemaker, Flask|
|UI Component | This layer will provide the front end support for the the uptime analytics users to access the portal| Angular
|Test Case | Test cases are implemented for individual methods(Unit test) as well as the component level(AWS S3, RDS, Flask API). Different mocks were used to test these different components | pytest, mock_s3,mock_lambda 

## Pre Requisite 
 1. python version 3.6 needs to be installed
 2. pip3 needs to be installed
 3. dependencies can found at setup.py in the respective individual module
 
 # NOTE
   Please refer to the respective modules Readme file for the installation  
