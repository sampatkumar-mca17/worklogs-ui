import json
from utils import config
from flask_mail import Mail, Message
def send_mail(app, request):
    message_body = request.get('body')
    message_body = json.dumps(message_body, indent=4)
    mail = Mail(app)
    msg = Message('Hello you have received all your worklogs', sender = config.MAIL_USERNAME, recipients = [config.MAIL_RECEPIENT])
    msg.body = message_body
    mail.send(msg)
    response = {'message':'sent'}
    return response