from sqlalchemy import desc
from utils import db_op_handler
from model.project import Project, project_schema
from model.worklog import Worklog, worklog_schema
from .model.get_worklogs_response import GetWorklogsResponse
from .model.get_all_worklogs import GetAllWorklogs
import json

def create_worklog(request):
    project_name = request.get("project_name")
    log_hours = request.get("log_hours")
    status = request.get("status", None)
    project_description = request.get("project_description", None)
    project = project_schema.load(request)
    project.project_name = project_name
    project.project_description = project_description
    project.worklog = worklog_schema.load({"log_hours":log_hours})
    project.status = status
    
    db_op_handler.add(project)
    
    response = {
        "project_name": project.project_name,
        "project_id": project.project_id,
        "created_on":project.created_on,
        "updated_on": project.updated_on,
        "created_by":project.created_by
    }
    return response

def get_worklog(project_id):
    project = Project.query.get(project_id)
    if(project is None):
        return "Requested data not found on server"
    resp = GetWorklogsResponse(project)
    return resp.to_json()

def get_worklogs():
    projects = Project.query.order_by(desc(Project.created_on)).all()
    if(not len(projects)):
        return []
    resps = []
    for project in projects:
        resp = GetAllWorklogs(project)
        resps.append(resp.to_json())
    
    return resps

def delete_worklog(project_id):
    project = Project.query.get(project_id)
    if(project is None):
        return"Requested data not found on server"
    project.mark_for_deletion = True
    db_op_handler.add(project)
    
    return "204"

def update_worklog(project_id,request):
    project = Project.query.get(project_id)
    if project is None:
        return "Requested data not found on server"
    db_op_handler.update(project, request)
    db_op_handler.update(project.worklog, request)
    
    resp = GetWorklogsResponse(project)
    return resp.to_json()
    
    
    
    
    