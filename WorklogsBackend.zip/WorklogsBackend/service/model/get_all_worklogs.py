from flask import g
from ..user_service import get_user_id
class GetAllWorklogs():
    def __init__(self, project):
        self.project_name = project.project_name
        self.project_description = project.project_description
        self.log_hours = project.worklog.log_hours
        self.user = get_user_id()
        self.email = g.USER_EMAIL
        self.project_id = project.project_id
        self.created_on = project.created_on
    def to_json(self):
        return vars(self)