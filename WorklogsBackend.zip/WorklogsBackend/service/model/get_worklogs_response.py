class GetWorklogsResponse():
    def __init__(self, project):
        self.project_name = project.project_name
        self.project_id = str(project.project_id)
        self.project_description = project.project_description
        self.log_hours = project.worklog.log_hours
        self.created_on = project.created_on
        
    def to_json(self):
        return vars(self)