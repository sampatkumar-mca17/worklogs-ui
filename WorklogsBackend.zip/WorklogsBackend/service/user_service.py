from flask import g
def get_user_id():
    return g.USER_ID