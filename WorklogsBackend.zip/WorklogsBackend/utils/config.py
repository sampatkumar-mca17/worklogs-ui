MAIL_USERNAME = 'sdupse417@gmail.com'
MAIL_PASSWORD = 'S9008805161D'
MAIL_RECEPIENT = 'sampatkumar.mca17@gmail.com'


