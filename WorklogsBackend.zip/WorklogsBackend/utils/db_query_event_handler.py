from sqlalchemy import event
from sqlalchemy import inspect
from sqlalchemy.orm import Session

from service import user_service
import logging

logger = logging.getLogger(__name__)


class DatabaseEventHandler:
    """
        Class for handling Database-related event handlers.

    """

    @staticmethod
    @event.listens_for(Session, "do_orm_execute", retval=True)
    def _do_orm_execute(orm_execute_state):
        """
            Listens to Query events (eg. Uptime.query.filter_by()) and adds a filter for tenant_id.

        :return: Query with tenant filter
        """
        if orm_execute_state.is_select:
            col_descriptions = orm_execute_state.statement.column_descriptions
            for ent in col_descriptions:
                entity = ent['entity']
                if entity is None:
                    continue
                
                inspect_entity_for_mapper = inspect(ent['entity'])
                mapper = getattr(inspect_entity_for_mapper, 'mapper', None)
                
                # Checking if the table has tenant_id attribute or not
                has_user_id = getattr(entity, 'user_id', None)
                if mapper and has_user_id:
                    user_id = user_service.get_user_id()
                    if user_id:
                        logger.info('Adding query filter for user: {}'.format(user_id))
                        orm_execute_state.statement = orm_execute_state.statement.filter(
                            entity.user_id == user_id)
                        
                        # Filtering rows which are marked for deletion   
                is_mark_for_deletion = getattr(entity, 'mark_for_deletion', None)
                if mapper and is_mark_for_deletion:
                    logger.info('Filtering deleted rows')
                    orm_execute_state.statement = orm_execute_state.statement.filter(
                        entity.mark_for_deletion == False)