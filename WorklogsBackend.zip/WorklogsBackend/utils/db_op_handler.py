import logging

from model import db

logger = logging.getLogger(__name__)


def add(instance):
    """
    Persists the given instance in database

    :param instance: Instance to be saved to database
    """

    logger.info('Saving data to database')
    db.session.add(instance)
    db.session.commit()
    db.engine.dispose()
    print('Saved data successfully')


def update(row, updated_data: dict):
    """
    Updates the given row with values from updated_data dict

    :param row: Database row to be updated
    :param updated_data: the updated values dict
    """
    # Setting only those values  which are sent by UI
    for key, val in updated_data.items():
        setattr(row, key, val)
    add(row)


def add_all(instances):
    """
    Persists the given collection of instances in database

    :param instances: Collection of instances to be persisted
    """
    db.session.add_all(instances)
    db.session.commit()
    db.engine.dispose()


def close_session():
    if db and db.session and db.engine:
        logger.info("Closing db session")
        db.session.close()
        db.session.remove()
        db.engine.dispose()
    logger.info("Closed db session")


def commit():
    db.session.commit()
    db.engine.dispose()
