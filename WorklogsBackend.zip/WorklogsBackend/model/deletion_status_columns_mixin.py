from sqlalchemy import Column, String, Boolean
from . import marshmallow
from marshmallow import fields


class DeletionStatusColumnsMixin(object):
    """
    Status (Active, Inactive) and Deletion columns mixin
    """
    status = Column(String)
    mark_for_deletion = Column(Boolean, default=False)


class DeletionStatusColumnsSchema(marshmallow.SQLAlchemyAutoSchema):
    # Not loading and dumping deletion fields as they are read only. If these fields are required to
    # display on UI, then override them in the specific class and make load_only=False & dump_only=False
    mark_for_deletion = fields.Field(load_only=True, dump_only=True)
    status = fields.Field(load_only=True, dump_only=True)
