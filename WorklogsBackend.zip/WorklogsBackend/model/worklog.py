from sqlalchemy.orm import relationship
from . import db
import uuid
from sqlalchemy import (BigInteger, Boolean, Column, Float, ForeignKey,
                        Integer, String)
from marshmallow import EXCLUDE, post_load
from . import marshmallow
from sqlalchemy.dialects.postgresql import JSONB, UUID



class Worklog(db.Model):
    __tablename__ = 'worklog'
    __table_args__ = {'schema': 'worklogs'}
    schema = 'worklogs'

    worklog_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    log_hours = Column(String)
    project_id = Column(UUID(as_uuid=True), ForeignKey(schema + '.project.project_id'))

class WorklogSchema(marshmallow.SQLAlchemyAutoSchema):
    class Meta:
        model = Worklog
        unknown = EXCLUDE
        include_fk = True
    @post_load
    def make_case(self, data, **kwargs):
        return Worklog(**data)

# For dumping Single object
worklog_schema = WorklogSchema()

# For dumping Collection
worklogs_schema = WorklogSchema(many=True)


