import logging

from flask_migrate import upgrade, stamp


class DatabaseManagementService(object):
    logger = logging.getLogger(__name__)

    @classmethod
    def stamp_db(cls):
        cls.logger.info('Stamping database to latest revision')
        stamp(directory='./migrations')

    @classmethod
    def manage_db(cls):
        cls.logger.debug("Test debug")
        cls.logger.info('Upgrading db to latest revision')
        upgrade(directory='./migrations')
