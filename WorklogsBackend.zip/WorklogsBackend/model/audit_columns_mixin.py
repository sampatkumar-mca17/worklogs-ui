import time

from flask import g
from sqlalchemy import Column, String, BigInteger
from sqlalchemy import event

from . import marshmallow


class AuditColumnsMixin(object):
    """
        Mixin class for common creation and updation columns present in tables.

    """
    created_on = Column(BigInteger)
    updated_on = Column(BigInteger)
    created_by = Column(String)
    updated_by = Column(String)

    @staticmethod
    def populate_fields_before_insert(mapper, connection, target):
        target.created_on = int(time.time())
        target.updated_on = int(time.time())

        target.created_by = g.USER_EMAIL
        target.updated_by = g.USER_EMAIL
        

    @staticmethod
    def populate_fields_before_update(mapper, connection, target):
        target.updated_on = int(time.time())
        target.updated_by = g.USER_EMAIL
        
    @classmethod
    def __declare_last__(cls):
        event.listen(AuditColumnsMixin, 'before_insert', cls.populate_fields_before_insert, propagate=True)
        event.listen(AuditColumnsMixin, 'before_update', cls.populate_fields_before_update, propagate=True)