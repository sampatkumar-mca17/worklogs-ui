from sqlalchemy import Column, String
from sqlalchemy import event
from service import user_service

class UserColumnMixin(object):
    """
    Mixin class for tenant specific columns
    """

    tenant_id = Column(String)

    @staticmethod
    def populate_user_fields_before_insert(mapper, connection, target):
        target.tenant_id = user_service.get_user_id()

    @classmethod
    def __declare_first__(cls):
        event.listen(UserColumnMixin, 'before_insert', cls.populate_user_fields_before_insert, propagate=True)