from . import db
import uuid
from sqlalchemy import (BigInteger, Boolean, Column, Float, ForeignKey,
                        Integer, String)
from marshmallow import EXCLUDE, fields, post_load
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import relationship
from .audit_columns_mixin import AuditColumnsMixin
from .deletion_status_columns_mixin import (DeletionStatusColumnsMixin,
                                            DeletionStatusColumnsSchema)
from .user_column_mixin import UserColumnMixin


class Project(AuditColumnsMixin, UserColumnMixin, DeletionStatusColumnsMixin, db.Model):
    __tablename__ = 'project'
    __table_args__ = {'schema': 'worklogs'}
    schema = 'worklogs'

    project_id = Column(UUID(as_uuid=True),
                        primary_key=True, default=uuid.uuid4)
    project_name = Column(String, nullable=False)
    project_description = Column(String)

    worklog = relationship("Worklog", uselist=False)

class ProjectSchema(DeletionStatusColumnsSchema):
    class Meta:
        model = Project
        unknown = EXCLUDE
        include_fk = True

    # Overriding status field from DeletionColumnsSchema to send in response
    status = fields.Field(load_only=False, dump_only=False)

    @post_load
    def make_case(self, data, **kwargs):
        return Project(**data)


# For dumping Single object
project_schema = ProjectSchema()

# For dumping Collection
projects_schema = ProjectSchema(many=True)
