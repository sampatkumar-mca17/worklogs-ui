from flask_sqlalchemy import SQLAlchemy
from flask_marshmallow import Marshmallow
from flask_migrate import Migrate

db = SQLAlchemy()
marshmallow = Marshmallow()
migrate = Migrate(compare_type=True)

from .worklog import Worklog
from .project import Project
