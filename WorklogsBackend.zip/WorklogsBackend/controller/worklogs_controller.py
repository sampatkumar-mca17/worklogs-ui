from flask import Blueprint, request, jsonify, g
from service import worklogs_service 
import logging

# from ..helper import helper
# from ..service import model_deployment_request_files_service

logger = logging.getLogger()

worklogs = Blueprint('worklog_controller_api', __name__, url_prefix='/rest/v1/user/<userid>/worklogs')

@worklogs.route("", methods=["POST"])
def create_worklogs(userid):
    """
        API to create worklogs
        :return: create response
    """
    resp = worklogs_service.create_worklog(request.json)
    return jsonify(resp)

@worklogs.route("/<project_id>", methods=["GET"])
def get_worklog(userid, project_id):
    """
        API to get worklog
        :return: get response
    """
    resp  = worklogs_service.get_worklog(project_id)
    return jsonify(resp)

@worklogs.route("", methods=["GET"])
def get_worklogs(userid):
    """
        API to get worklog
        :return: get response
    """
    resp  = worklogs_service.get_worklogs()
    return jsonify(resp)

@worklogs.route("/<project_id>", methods=["DELETE"])
def delete_worklog(userid, project_id):
    """
        API to get worklog
        :return: get response
    """
    resp = worklogs_service.delete_worklog(project_id)
    return jsonify(resp)

@worklogs.route("/<project_id>", methods=["PUT"])
def update_worklog(userid, project_id):
    """
        API to get worklog
        :return: get response
    """
    resp = worklogs_service.update_worklog(project_id,request.json)
    return jsonify(resp)