import json
import logging
import uuid
from flask import request, Blueprint, g

logger = logging.getLogger(__name__)
request_interceptor = Blueprint('request_interceptor', __name__)


@request_interceptor.before_app_request
def handle_incoming_requests():
    # g.CORRELATION_ID = request.headers.get('X-Correlation-Id', str(uuid.uuid4()))
    
    logger.info("Intercepted request and adding tenant id and user email to global context")

    # Setting tenant id
    g.USER_ID = None
    if request.view_args:
        user_id = request.view_args['userid']
        g.USER_ID = user_id

    # Setting email
    g.USER_EMAIL = None
    if request.form:
        for key, val in request.form.items():
            if val:
                request_body = json.loads(val)
                if request_body:
                    email = request_body.get('email')
                    g.USER_EMAIL = email
    elif request.get_json():
        email = request.get_json().get('email')
        g.USER_EMAIL = email
